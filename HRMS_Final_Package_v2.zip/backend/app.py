
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import pandas as pd
import io, os, json

app = FastAPI(title="HRMS Backend", version="1.0")

# ---- Health ----
@app.get("/api/health")
def health():
    return {"ok": True}

# ---- Payroll stub endpoints (placeholders) ----
@app.post("/api/payroll/cycles/{cycle_id}/submit-mudad")
def submit_mudad(cycle_id: str, bankConnector: str = "alrajhi", simulate: bool = True):
    # In real impl: generate WPS CSV and push via bank connector
    return {"cycleId": cycle_id, "status": "submitted", "connector": bankConnector, "simulate": simulate, "reference": "WPS-REF-12345"}

# ---- Attendance punch stub ----
@app.post("/api/attendance/punch")
def punch():
    return {"status":"ok","msg":"attendance recorded (stub)"}

# ---- Letters issue stub ----
@app.post("/api/letters/salary_certificate/issue")
def issue_letter():
    return {"status":"ok","url":"/storage/letters/letter-123.pdf"}

# ---- AI runner ----
try:
    from sklearn.model_selection import train_test_split
    from sklearn.linear_model import LinearRegression
    from sklearn.tree import DecisionTreeClassifier
    SK_AVAILABLE = True
except Exception as e:
    SK_AVAILABLE = False

def run_python_linear_regression(df: pd.DataFrame, target: str):
    X = df.drop(columns=[target])
    y = df[target]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)
    model = LinearRegression().fit(X_train, y_train)
    r2 = model.score(X_test, y_test)
    return {"engine":"python_sklearn","algo":"linear_regression","r2": float(r2)}

def run_python_decision_tree(df: pd.DataFrame, target: str):
    X = df.drop(columns=[target])
    y = df[target]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)
    clf = DecisionTreeClassifier(random_state=42).fit(X_train, y_train)
    acc = float((clf.score(X_test, y_test)))
    return {"engine":"python_sklearn","algo":"decision_tree","accuracy": acc}

def run_octave_script(script_name: str, df: pd.DataFrame):
    """
    If oct2py + Octave are installed, pass a CSV to Octave and call the script.
    We will save df to /tmp/input.csv and expect the script to read it.
    """
    try:
        from oct2py import octave
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            csv_path = os.path.join(td,"input.csv")
            df.to_csv(csv_path, index=False)
            octave.addpath(os.getcwd())
            res = octave.feval(script_name.replace(".m",""), csv_path, nout=1)
            # expect res to be JSON string or numeric value
            return {"engine":"octave", "script":script_name, "result": str(res)}
    except Exception as e:
        return {"engine":"octave","script":script_name,"error":str(e)}

@app.post("/api/ai/run")
async def ai_run(
    algorithm: str = Form(...),
    target: str = Form("target"),
    file: UploadFile = File(...)
):
    data = await file.read()
    try:
        df = pd.read_csv(io.BytesIO(data))
    except Exception as e:
        return JSONResponse(status_code=400, content={"error": f"CSV parse failed: {e}"})
    algorithm = algorithm.lower()
    # Python-native fallbacks
    if SK_AVAILABLE and algorithm in ("linear_regression","decision_tree"):
        if target not in df.columns:
            return JSONResponse(status_code=400, content={"error": f"Target '{target}' not found in columns: {list(df.columns)}"})
        if algorithm == "linear_regression":
            return run_python_linear_regression(df, target)
        else:
            return run_python_decision_tree(df, target)

    # Delegate to Octave/MATLAB scripts if available
    script_map = {
        "ann":"ann.m",
        "ga_selection":"GA_Selection.m",
        "pso":"TESTforPSO.m",
        "linear_regression":"linear_regression.m",
        "decision_tree":"Dicision_tree.m"
    }
    if algorithm in script_map:
        return run_octave_script(script_map[algorithm], df)

    return JSONResponse(status_code=400, content={"error": "Unknown algorithm"})



from fastapi import Response
import datetime as _dt

def _csv_bytes(s: str):
    return s.encode("utf-8-sig")

@app.post("/api/payroll/wps/generate")
async def wps_generate(payload: dict):
    """
    Generate a generic WPS CSV from JSON payload.
    Expected payload:
    {
      "period_start": "2025-10-01",
      "period_end": "2025-10-31",
      "employees": [
         {"employee_id":"1001","name":"Ahmed","iban":"SA...", "net":10330.00},
         ...
      ]
    }
    """
    period_start = payload.get("period_start")
    period_end = payload.get("period_end")
    employees = payload.get("employees", [])
    # Minimal transferable format (adapt with bank connector mapping)
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(["EmployeeID","Name","IBAN","NetAmount","PeriodStart","PeriodEnd"])
    for e in employees:
        writer.writerow([e.get("employee_id",""), e.get("name",""), e.get("iban",""), e.get("net",0), period_start, period_end])
    return Response(content=_csv_bytes(out.getvalue()), media_type="text/csv")

@app.get("/api/payroll/cycles/{cycle_id}/wps.csv")
def wps_cycle_csv(cycle_id: str):
    """Generate a sample WPS CSV from sample payroll file for quick testing."""
    sample_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "samples", "hr_payroll_sample.csv")
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(["EmployeeID","Name","IBAN","NetAmount","PeriodStart","PeriodEnd"])
    rows = []
    try:
        with open(sample_path, "r", encoding="utf-8") as f:
            rdr = csv.DictReader(f)
            idx = 1001
            for r in rdr:
                rows.append([str(idx), f"Emp{idx}", f"SA{idx:022d}", r.get("net","0"), "2025-10-01","2025-10-31"])
                idx += 1
    except Exception:
        rows = [["1001","Emp1001","SA000","9000","2025-10-01","2025-10-31"]]
    for row in rows:
        writer.writerow(row)
    return Response(content=_csv_bytes(out.getvalue()), media_type="text/csv")

@app.post("/api/payroll/export-gl")
async def payroll_export_gl(payload: dict):
    """
    Export GL entries CSV.
    Expected payload:
    {
      "date": "2025-10-31",
      "entries": [
         {"employee_id":"1001","basic":8000,"allowances":2000,"overtime":450,"deductions":120,"net":10330,"cost_center":"FIN"},
         ...
      ],
      "accounts": {"basic":"5010","allowances":"5020","overtime":"5030","deductions":"2090","net_pay":"1060"}
    }
    """
    entries = payload.get("entries", [])
    accounts = payload.get("accounts", {})
    date = payload.get("date", _dt.date.today().isoformat())
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(["Date","Account","Debit","Credit","CostCenter","EmployeeID","Memo"])
    # Debit expenses
    for e in entries:
        cc = e.get("cost_center","")
        emp = e.get("employee_id","")
        for key, acct in [("basic","basic"),("allowances","allowances"),("overtime","overtime")]:
            val = float(e.get(key,0))
            if val>0:
                writer.writerow([date, accounts.get(acct,""), f"{val:.2f}", "", cc, emp, f"{key}"])
        ded = float(e.get("deductions",0))
        if ded>0:
            writer.writerow([date, accounts.get("deductions",""), "", f"{ded:.2f}", cc, emp, "deductions"])
        net = float(e.get("net",0))
    # Credit net pay (summary credit)
    total_net = sum(float(e.get("net",0)) for e in entries)
    writer.writerow([date, accounts.get("net_pay",""), "", f"{total_net:.2f}", "", "", "net pay"])
    return Response(content=_csv_bytes(out.getvalue()), media_type="text/csv")

# ---- Requests: Lost Fingerprint / Permission / Advance ----
@app.post("/api/requests/lost-fingerprint")
async def req_lost_fingerprint(payload: dict):
    payload["status"] = "pending"
    payload["request_type"] = "lost_fingerprint"
    return payload

@app.post("/api/requests/permission")
async def req_permission(payload: dict):
    payload["status"] = "pending"
    payload["request_type"] = "permission"
    return payload

@app.post("/api/requests/advance")
async def req_advance(payload: dict):
    payload["status"] = "pending"
    payload["request_type"] = "advance"
    return payload
