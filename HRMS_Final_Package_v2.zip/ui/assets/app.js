
// Simple HRMS UI prototype interactions
function setActive(navId){
  const links = document.querySelectorAll('.nav a');
  links.forEach(a=>a.classList.remove('active'));
  const el = document.getElementById(navId);
  if(el) el.classList.add('active');
}
function toast(msg){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.style.display = 'block';
  setTimeout(()=> t.style.display = 'none', 2500);
}
function openModal(id){ document.getElementById(id).style.display='flex'; }
function closeModal(id){ document.getElementById(id).style.display='none'; }
function togglePayrollReady(chk){
  const btn = document.getElementById('btnPay');
  btn.disabled = !chk.checked;
}
function submitMudad(){
  closeModal('modalSubmit');
  toast('تم إرسال مسير الرواتب إلى منصة مدد (تجريبي)');
}
function addShift(day){
  toast('تم إضافة وردية ليوم: '+day);
}
