# HRMS Final Package (UI + Backend + DB + Letters + ML)
تجميعة نهائية تشمل:
- **db/hrms_schema.sql** — مخطط قاعدة البيانات.
- **api/hrms_postman_collection.json** — مجموعة Postman (تتضمن الآن مسار AI).
- **ui/** — واجهة عربية RTL كاملة مع صفحة **الذكاء الاصطناعي**.
- **letters/** — قوالب خطابات Word جاهزة.
- **backend/** — كود FastAPI يشمل نقاط استرشادية + واجهة AI.
- **ml/** — الأكواد التي أرسلتها لنا (.m) مدمجة كما هي.
- **samples/** — ملفات CSV للتجربة.

## تشغيل الواجهة (ثابت)
افتح `ui/index.html` في المتصفح.

## تشغيل الباك-إند (يتطلب Python 3.10+)
```bash
cd backend
python -m venv .venv && source .venv/bin/activate  # على ويندوز: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app:app --reload --port 8000
```
ثم عدّل مسار الاستدعاء في الواجهة أو عبر Proxy ليكون `/api/...` موجهاً إلى `http://localhost:8000`.

> **ملاحظة:** خوارزميات **linear_regression** و **decision_tree** تعمل مباشرة عبر scikit-learn.
> خوارزميات **ann** و **ga_selection** و **pso** تستخدم ملفات MATLAB/Octave المرفقة. لتفعيلها:
> - ثبت Octave وقم بتثبيت مكتبة `oct2py` (موجودة في requirements).
> - تأكد أن الخادم يستطيع الوصول لمجلد `ml/` (ضعه في current working directory).

## إرسال الرواتب إلى "مدد"
المسار `/api/payroll/cycles/{id}/submit-mudad` موجود كـ **Stub**. اربطه بموصل البنك/WPS في بيئة الإنتاج واستبدل المنطق داخل الدالة.

## الأمان والامتثال PDPL
أضف طبقات المصادقة (JWT/OAuth2) وقيود الوصول RBAC وسجلات التدقيق قبل الإطلاق الفعلي.

آخر تحديث: 2025-11-04 08:21
