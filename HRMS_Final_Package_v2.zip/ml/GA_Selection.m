function  GA_Selection()
%% This is an auto generated MATLAB file from Optimization Tool.
%DATA
global training_data
global training_y

Data=[
94	90	80	80	71	83
71	80	80	77	70	75.6
74	80	70	83	60	73.4
50	74	58	70	50	60.4
71	73	77	71	71	72.6
77	72	59	70	77	71
90	90	81	80	77	83.6
70	80	80	70	70	74
70	70	50	50	79	63.8
80	80	59	70	78	73.4
73	74	70	76	70	72.6
70	70	59	70	77	69.2
90	77	87	84	72	82
79	79	89	79	79	81
77	81	80	80	69	77.4
59	70	70	70	70	67.8
70	70	70	74	72	71.2
70	70	59	59	70	65.6
70	77	85	88	77	79.4
70	80	86	77	85	79.6
76	90	76	80	69	78.2
59	70	59	70	59	63.4
75	74	74	73	71	73.4
70	70	59	70	70	67.8
90	87	80	80	87	84.8
79	77	89	79	79	80.6
];

[ii jj]=size(Data);
rand('seed',100);
index=randperm(ii);
rData=Data(index,:);
input=rData(:,1:jj-1);
classes=rData(:,jj);
partition=0.8;
pos=round(ii*partition);
training_data=input(1:pos,:);
testing_data=input(pos+1:ii,:);
training_y=classes(1:pos,:);
testing_y=classes(pos+1:ii,:);

%% Start with the default options
options = optimoptions('ga');
%% Modify options setting
options = optimoptions(options,'Display', 'off');
lb=[0 0 0 0 0];
ub=[3 3 3 3 3];
nvars=jj-1;
[B,fval,exitflag,output,population,score] = ga(@Candidate,nvars,[],[],[],[],lb,ub,[],[],options);

disp(B);
disp(fval);
training_predict=sum(B'.*training_data');
testing_predict=sum(B'.*testing_data');
figure(1);
plot(training_y',training_predict,'.');
figure(2);
plot(testing_y',testing_predict,'.');
train_rms = rms(training_y'-training_predict)
test_rms = rms(testing_y'-testing_predict)



function train_rms = Candidate(B)
global training_data
global training_y
training_predict=sum(B'.*training_data');
train_rms=rms(training_y'-training_predict);


