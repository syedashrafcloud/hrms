
-- HRMS Core Schema (PostgreSQL) - v1.0 (Saudi context, RTL-friendly content in comments)
-- Generated: 2025-11-04T08:00:50.502166
-- Notes:
-- - All timestamps are UTC; store local offsets in app layer if needed.
-- - Use row-level security / RBAC at the application layer.
-- - UUIDs are preferred as PKs. Replace with BIGSERIAL if preferred.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

----------------------
-- Reference tables --
----------------------
CREATE TABLE companies (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code TEXT UNIQUE NOT NULL,
  name_ar TEXT NOT NULL,
  name_en TEXT,
  cr_number TEXT,            -- السجل التجاري
  tax_number TEXT,
  gosi_number TEXT,
  mudad_customer_id TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE branches (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code TEXT,
  name_ar TEXT NOT NULL,
  name_en TEXT,
  city TEXT,
  latitude NUMERIC(10,6),
  longitude NUMERIC(10,6),
  geofence_radius_m INTEGER DEFAULT 150, -- للنقطة الجغرافية للحضور بالجوال
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE departments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  parent_id UUID REFERENCES departments(id) ON DELETE SET NULL,
  name_ar TEXT NOT NULL,
  name_en TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE jobs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code TEXT,
  title_ar TEXT NOT NULL,
  title_en TEXT,
  grade TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

------------------
-- Auth & Users --
------------------
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  password_hash TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE roles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code TEXT UNIQUE NOT NULL,
  name_ar TEXT NOT NULL,
  name_en TEXT
);

CREATE TABLE user_roles (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  PRIMARY KEY(user_id, role_id)
);

----------------
-- Employees  --
----------------
CREATE TABLE employees (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  branch_id UUID REFERENCES branches(id) ON DELETE SET NULL,
  department_id UUID REFERENCES departments(id) ON DELETE SET NULL,
  job_id UUID REFERENCES jobs(id) ON DELETE SET NULL,
  emp_no TEXT UNIQUE,
  national_id TEXT,     -- هوية/إقامة
  iqama_no TEXT,
  iqama_expiry DATE,
  passport_no TEXT,
  passport_expiry DATE,
  full_name_ar TEXT NOT NULL,
  full_name_en TEXT,
  email TEXT,
  phone TEXT,
  hire_date DATE,
  status TEXT CHECK (status IN ('active','suspended','terminated','resigned')) DEFAULT 'active',
  basic_salary NUMERIC(12,2) DEFAULT 0,
  bank_name TEXT,
  iban TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE employee_documents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  doc_type TEXT,               -- إقامة، جواز، عقد، تأمين...
  doc_no TEXT,
  issue_date DATE,
  expiry_date DATE,
  storage_uri TEXT,            -- رابط التخزين (S3/Blob)
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE tags (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code TEXT UNIQUE,
  name TEXT NOT NULL
);

CREATE TABLE employee_tags (
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  tag_id UUID NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  PRIMARY KEY(employee_id, tag_id)
);

CREATE TABLE employee_assets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  asset_code TEXT NOT NULL,      -- العهدة
  asset_name TEXT NOT NULL,
  handed_on DATE,
  returned_on DATE,
  notes TEXT
);

-----------------
-- Attendance  --
-----------------
CREATE TABLE attendance_devices (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  device_sn TEXT UNIQUE NOT NULL,
  model TEXT,
  ip_address TEXT,
  location TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE attendance_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  source TEXT CHECK (source IN ('device','mobile','web')),
  event_type TEXT CHECK (event_type IN ('in','out')),
  event_time TIMESTAMP NOT NULL,
  latitude NUMERIC(10,6),
  longitude NUMERIC(10,6),
  device_sn TEXT,
  raw_payload JSONB
);

CREATE INDEX ON attendance_logs (employee_id, event_time);

CREATE TABLE shifts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code TEXT UNIQUE,
  name TEXT NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  break_minutes INTEGER DEFAULT 0,
  overtime_after_minutes INTEGER DEFAULT 0,
  is_overnight BOOLEAN DEFAULT FALSE
);

CREATE TABLE shift_assignments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  shift_id UUID NOT NULL REFERENCES shifts(id) ON DELETE CASCADE,
  start_date DATE NOT NULL,
  end_date DATE,
  UNIQUE(employee_id, shift_id, start_date)
);

CREATE TABLE attendance_violations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  violation_date DATE NOT NULL,
  code TEXT,                    -- تأخير، انصراف مبكر، غياب
  minutes INTEGER DEFAULT 0,
  auto_generated BOOLEAN DEFAULT TRUE,
  notes TEXT
);

----------------
-- Leaves     --
----------------
CREATE TABLE leave_policies (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code TEXT UNIQUE,
  name_ar TEXT NOT NULL,
  name_en TEXT,
  type TEXT, -- annual, sick, maternity, hajj, unpaid...
  accrual_days_per_year NUMERIC(6,2) DEFAULT 0,
  carry_over_limit NUMERIC(6,2) DEFAULT 0,
  requires_attachment BOOLEAN DEFAULT FALSE,
  is_paid BOOLEAN DEFAULT TRUE
);

CREATE TABLE leave_balances (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  policy_id UUID NOT NULL REFERENCES leave_policies(id) ON DELETE CASCADE,
  balance NUMERIC(6,2) DEFAULT 0,
  as_of DATE NOT NULL DEFAULT CURRENT_DATE,
  UNIQUE(employee_id, policy_id, as_of)
);

CREATE TABLE leave_requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  policy_id UUID NOT NULL REFERENCES leave_policies(id) ON DELETE CASCADE,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  days NUMERIC(6,2) NOT NULL,
  status TEXT CHECK (status IN ('draft','pending','approved','rejected','cancelled')) DEFAULT 'pending',
  reason TEXT,
  attachment_uri TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

----------------
-- Payroll    --
----------------
CREATE TABLE payroll_cycles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code TEXT UNIQUE,
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  payment_date DATE,
  status TEXT CHECK (status IN ('open','locked','submitted','paid','failed')) DEFAULT 'open',
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE payroll_employees (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cycle_id UUID NOT NULL REFERENCES payroll_cycles(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  included BOOLEAN DEFAULT TRUE,
  UNIQUE(cycle_id, employee_id)
);

CREATE TABLE allowances_master (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code TEXT UNIQUE,
  name TEXT NOT NULL,
  taxable BOOLEAN DEFAULT TRUE,
  recurring BOOLEAN DEFAULT TRUE
);

CREATE TABLE deductions_master (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code TEXT UNIQUE,
  name TEXT NOT NULL,
  is_pre_tax BOOLEAN DEFAULT FALSE,
  recurring BOOLEAN DEFAULT TRUE
);

CREATE TABLE employee_allowances (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  allowance_id UUID NOT NULL REFERENCES allowances_master(id) ON DELETE CASCADE,
  amount NUMERIC(12,2) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE
);

CREATE TABLE employee_deductions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  deduction_id UUID NOT NULL REFERENCES deductions_master(id) ON DELETE CASCADE,
  amount NUMERIC(12,2) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE
);

CREATE TABLE loans (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  principal NUMERIC(12,2) NOT NULL,
  start_date DATE NOT NULL,
  months INTEGER NOT NULL,
  status TEXT CHECK (status IN ('active','settled','cancelled')) DEFAULT 'active'
);

CREATE TABLE loan_schedules (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  loan_id UUID NOT NULL REFERENCES loans(id) ON DELETE CASCADE,
  due_date DATE NOT NULL,
  amount NUMERIC(12,2) NOT NULL,
  paid BOOLEAN DEFAULT FALSE,
  paid_on DATE
);

CREATE TABLE payroll_lines (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cycle_id UUID NOT NULL REFERENCES payroll_cycles(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  basic NUMERIC(12,2) DEFAULT 0,
  overtime NUMERIC(12,2) DEFAULT 0,
  allowances JSONB DEFAULT '[]'::jsonb,
  deductions JSONB DEFAULT '[]'::jsonb,
  loans NUMERIC(12,2) DEFAULT 0,
  net_salary NUMERIC(12,2) DEFAULT 0,
  wps_status TEXT,  -- draft/submitted/accepted/rejected
  wps_reference TEXT,
  notes TEXT,
  UNIQUE(cycle_id, employee_id)
);

--------------------------
-- Approvals & Letters  --
--------------------------
CREATE TABLE approvals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  module TEXT,          -- leaves, letters, loans, etc.
  record_id UUID,       -- points to target record
  status TEXT CHECK (status IN ('draft','pending','approved','rejected')) DEFAULT 'pending',
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE approval_steps (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  approval_id UUID NOT NULL REFERENCES approvals(id) ON DELETE CASCADE,
  step_order INTEGER NOT NULL,
  approver_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  step_status TEXT CHECK (step_status IN ('pending','approved','rejected','skipped')) DEFAULT 'pending',
  decision_at TIMESTAMP,
  notes TEXT
);

CREATE TABLE letters (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  letter_type TEXT,   -- salary_certificate, employment_proof, bank_letter
  language TEXT DEFAULT 'ar',
  content JSONB,      -- tokens used to render document
  issued_at TIMESTAMP NOT NULL DEFAULT NOW(),
  storage_uri TEXT
);

------------------------------
-- Performance & Talent     --
------------------------------
CREATE TABLE performance_cycles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code TEXT UNIQUE,
  name TEXT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status TEXT CHECK (status IN ('draft','open','closed')) DEFAULT 'draft'
);

CREATE TABLE goals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  cycle_id UUID NOT NULL REFERENCES performance_cycles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  weight NUMERIC(5,2) DEFAULT 0,
  progress NUMERIC(5,2) DEFAULT 0
);

CREATE TABLE evaluations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  cycle_id UUID NOT NULL REFERENCES performance_cycles(id) ON DELETE CASCADE,
  overall_score NUMERIC(5,2),
  comments TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE succession_plans (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  role_id UUID REFERENCES jobs(id),
  candidate_employee_id UUID REFERENCES employees(id),
  readiness TEXT,   -- ready_now, <6m, <12m
  notes TEXT
);

------------------------------
-- ATS & Recruitment        --
------------------------------
CREATE TABLE requisitions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code TEXT UNIQUE,
  title TEXT NOT NULL,
  department_id UUID REFERENCES departments(id),
  job_id UUID REFERENCES jobs(id),
  openings INTEGER DEFAULT 1,
  status TEXT CHECK (status IN ('draft','open','on_hold','closed','cancelled')) DEFAULT 'open',
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE candidates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  requisition_id UUID NOT NULL REFERENCES requisitions(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  cv_uri TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE candidate_stages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  candidate_id UUID NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
  stage TEXT,  -- applied, screening, interview, offer, hired, rejected
  decision TEXT,
  decision_at TIMESTAMP,
  notes TEXT
);

------------------------------
-- Surveys                   --
------------------------------
CREATE TABLE surveys (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code TEXT UNIQUE,
  title TEXT NOT NULL,
  is_anonymous BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE survey_questions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  survey_id UUID NOT NULL REFERENCES surveys(id) ON DELETE CASCADE,
  order_no INTEGER NOT NULL,
  q_type TEXT, -- likert, text, mcq
  text TEXT NOT NULL,
  options JSONB
);

CREATE TABLE survey_responses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  survey_id UUID NOT NULL REFERENCES surveys(id) ON DELETE CASCADE,
  employee_id UUID REFERENCES employees(id) ON DELETE SET NULL,
  submitted_at TIMESTAMP NOT NULL DEFAULT NOW(),
  answers JSONB
);

------------------------------
-- Integrations & Webhooks   --
------------------------------
CREATE TABLE integrations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  provider TEXT, -- mudad, gosi, muqeem, bank, erp
  client_id TEXT,
  client_secret TEXT,
  config JSONB,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE webhooks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  event TEXT,          -- bank.wps_status, biometric.push, etc.
  target_url TEXT NOT NULL,
  secret TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

------------------------------
-- Auditing                  --
------------------------------
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  actor_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  entity TEXT,     -- table name
  entity_id UUID,
  payload JSONB,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Helpful Indexes
CREATE INDEX ON employees (company_id, department_id, status);
CREATE INDEX ON payroll_lines (cycle_id, employee_id);
CREATE INDEX ON leave_requests (employee_id, status, start_date);
CREATE INDEX ON webhooks (company_id, event);
CREATE INDEX ON audit_logs (company_id, created_at DESC);

-- END OF SCHEMA
